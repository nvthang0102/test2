import React from 'react';

const FormRegister = () => {
    return(
        <>
            
        </>
    )
}
export default FormRegister;