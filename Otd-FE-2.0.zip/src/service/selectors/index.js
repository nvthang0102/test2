export const provinceSelector = (state) => state.province
export const accountSelector = (state) => state.account
export const commonSelector = (state) => state.common
export const serviceSelector = (state) => state.service
export const cardManagerSelector = (state) => state.cardManager
export const addCardSelector = (state) => state.addCard

