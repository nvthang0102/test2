var REACT_API_PROVINCE = 'https://provinces.open-api.vn/api/'
var URL_SERVER = 'https://api.onthedesk.vn:8443'
var GOOGLE_ID_CLIENT =
  '511936272698-0ibtabmv532171s9nvdacg95o58cr5n7.apps.googleusercontent.com'
